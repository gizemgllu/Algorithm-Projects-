# Gizem Gullu 230ADB075
# Maze Solver Implementation using A* Algorithm
# This program solves a maze finding the path from start (S) to goal (G) while 
# collecting the minimum number of coins possible.

import heapq
import sys
from typing import List, Tuple, Set

class Node:
    """
    Node class for A* pathfinding.
    Each node represents a position in the maze and stores:
    - Its position coordinates
    - Parent node (for reconstructing the path)
    - g: the actual cost from start to current node
    - h: heuristic estimate from current node to goal
    - f: total estimated cost (g + h)
    """
    def __init__(self, position: Tuple[int, int], parent=None):
        self.position = position
        self.parent = parent
        self.g = 0  # Cost from start to current node
        self.h = 0  # Heuristic cost from current to goal
        self.f = 0  # Total cost (g + h)

    def __lt__(self, other):
        # Comparison method for priority queue ordering
        return self.f < other.f

def read_maze(filename: str) -> List[List[str]]:
    """
    Read maze from file and return as 2D list.
    Performs basic validation on the maze structure and content.
    """
    try:
        with open(filename, 'r') as f:
            maze = [list(line.strip()) for line in f]
        
        # Basic validation
        if not maze:
            raise ValueError("Empty maze file")
        
        width = len(maze[0])
        for i, row in enumerate(maze):
            if len(row) != width:
                raise ValueError(f"Inconsistent maze width at row {i+1}")
            
            for j, cell in enumerate(row):
                if cell != 'X' and cell != 'S' and cell != 'G' and not (cell.isdigit() and 0 <= int(cell) <= 9):
                    raise ValueError(f"Invalid character '{cell}' at position ({i}, {j})")
                    
        return maze
    except FileNotFoundError:
        raise FileNotFoundError(f"Maze file '{filename}' not found")
    except Exception as e:
        raise ValueError(f"Error reading maze file: {str(e)}")

def find_positions(maze: List[List[str]]) -> Tuple[Tuple[int, int], Tuple[int, int]]:
    """
    Find start (S) and goal (G) positions in the maze.
    Returns a tuple containing the coordinates of both positions.
    """
    start = None
    goal = None
    for i in range(len(maze)):
        for j in range(len(maze[i])):
            if maze[i][j] == 'S':
                start = (i, j)
            elif maze[i][j] == 'G':
                goal = (i, j)
            if start and goal:
                return start, goal
    
    if not start:
        raise ValueError("Start position 'S' not found in maze")
    if not goal:
        raise ValueError("Goal position 'G' not found in maze")
    
    raise ValueError("Start or goal not found in maze")

def heuristic(a: Tuple[int, int], b: Tuple[int, int]) -> int:
    """
    Calculate Chebyshev distance between two points.
    This is the appropriate heuristic for problems that allow diagonal movement,
    as it represents the minimum number of moves needed in an obstacle-free grid.
    The Chebyshev distance is the maximum of the absolute differences of the coordinates.
    """
    return max(abs(a[0] - b[0]), abs(a[1] - b[1]))

def get_neighbors(maze: List[List[str]], pos: Tuple[int, int]) -> List[Tuple[int, int]]:
    """
    Get all valid neighboring positions (including diagonals).
    The function checks all 8 adjacent cells (4 orthogonal + 4 diagonal)
    and returns those that are within bounds and not walls ('X').
    """
    rows, cols = len(maze), len(maze[0])
    # All possible directions: top-left, top, top-right, left, right, bottom-left, bottom, bottom-right
    directions = [(-1,-1), (-1,0), (-1,1), (0,-1), (0,1), (1,-1), (1,0), (1,1)]
    neighbors = []
    
    for dx, dy in directions:
        new_x, new_y = pos[0] + dx, pos[1] + dy
        # Check if the new position is within maze boundaries and not a wall
        if 0 <= new_x < rows and 0 <= new_y < cols and maze[new_x][new_y] != 'X':
            neighbors.append((new_x, new_y))
    return neighbors

def a_star(maze: List[List[str]], start: Tuple[int, int], goal: Tuple[int, int]) -> List[Tuple[int, int]]:
    """
    A* algorithm to find path from start to goal with minimum coins collected.
    
    A* is ideal for this problem because:
    1. It guarantees the shortest path (minimum number of cells)
    2. It optimizes for minimum cost (coins in this case)
    3. It's generally more efficient than other pathfinding algorithms like Dijkstra's
       due to its heuristic-guided approach
    
    The algorithm maintains:
    - open_set: A priority queue of nodes to be evaluated
    - closed_set: A set of nodes already evaluated
    
    For each node, we calculate:
    - g: The actual cost from start to current node (coins collected)
    - h: A heuristic estimate from current node to goal (Chebyshev distance)
    - f: Total estimated cost (g + h)
    
    We always explore the node with lowest f value first.
    """
    open_set = []
    closed_set = set()
    
    start_node = Node(start)
    goal_node = Node(goal)
    
    # Add start node to open set
    heapq.heappush(open_set, start_node)
    
    while open_set:
        # Get node with lowest f score from open set
        current_node = heapq.heappop(open_set)
        closed_set.add(current_node.position)
        
        # If goal reached, reconstruct and return the path
        if current_node.position == goal:
            path = []
            while current_node:
                path.append(current_node.position)
                current_node = current_node.parent
            return path[::-1]  # Reverse path to get start-to-goal order
        
        # Check all neighbors
        for neighbor_pos in get_neighbors(maze, current_node.position):
            # Skip already evaluated positions
            if neighbor_pos in closed_set:
                continue
                
            # Create new node for this neighbor
            neighbor = Node(neighbor_pos, current_node)
            
            # Calculate g score (cost so far)
            # If the cell contains a digit, add its value to the cost
            # If it's S or G, add 0
            neighbor.g = current_node.g + int(maze[neighbor_pos[0]][neighbor_pos[1]]) if maze[neighbor_pos[0]][neighbor_pos[1]] not in ['S', 'G'] else current_node.g
            
            # Calculate heuristic (estimated cost to goal)
            neighbor.h = heuristic(neighbor_pos, goal)
            
            # Calculate f score (total estimated cost)
            neighbor.f = neighbor.g + neighbor.h
            
            # Check if this path to neighbor is better than any previous one
            for open_node in open_set:
                if open_node.position == neighbor_pos and open_node.f < neighbor.f:
                    break
            else:
                heapq.heappush(open_set, neighbor)
    
    return []  # No path found

def calculate_coins(maze: List[List[str]], path: List[Tuple[int, int]]) -> int:
    """
    Calculate total coins collected along the path.
    This sums the values of all cells in the path, excluding S and G.
    """
    total = 0
    for pos in path:
        cell = maze[pos[0]][pos[1]]
        if cell not in ['S', 'G']:
            total += int(cell)
    return total

def solve_maze(filename: str) -> int:
    """
    Main function to solve maze and return total coins collected.
    This function integrates all the pieces:
    1. Reads the maze file
    2. Finds start and goal positions
    3. Runs A* algorithm to find optimal path
    4. Calculates total coins collected
    """
    maze = read_maze(filename)
    start, goal = find_positions(maze)
    path = a_star(maze, start, goal)
    return calculate_coins(maze, path)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python maze_solver.py <maze_file>")
        sys.exit(1)
        
    filename = sys.argv[1]
    coins = solve_maze(filename)
    print(f"Total coins collected: {coins}") 