# Gizem Gullu 230ADB075
# this file processes all maze files 

import os
import sys
from maze_solver import solve_maze

def main():
    """
    process:
    First finds all maze files
    Then A* algorithm is used to solve maze
    Finally, gives outputs with the number of coins collected

    Error handling mechanism has been added as well.   

    """
    try:
        # checks for maze files in the directory
    
        maze_files = sorted([f for f in os.listdir('.') if f.endswith('.txt') and f.startswith('maze_')])
        
        if not maze_files:
            print("Error: No maze files found!")
            return
        
        results = []
        for maze_file in maze_files:
            try:
                print(f"Solving maze: {maze_file}")
            
                coins = solve_maze(maze_file)
                results.append(str(coins))
                print(f"Maze {maze_file}: {coins} coins collected")
            except FileNotFoundError:
                print(f"Error: {maze_file} not found.")
                sys.exit(1)
            except ValueError as e:
                print(f"Error  {maze_file}: {e}")
                sys.exit(1)
            except Exception as e:
                print(f"Unexpected error {maze_file}: {e}")
                sys.exit(1)
        
        # comma-separated string format 
        final_result = ','.join(results)
        print("\nAnswer is:")
        print(final_result)
    except Exception as e:
        print(f"An error occurred! : {e}")
        sys.exit(1)

if __name__ == '__main__':
    main() 